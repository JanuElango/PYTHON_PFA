Hi, i noticed the image folder is missing so download it from the link below and put the image folder in the same directory as the CSS Folder.
NOTE: Dm me if you don't really understand how to do this
Download Image Folder from this link below
https://drive.google.com/drive/folders/1ee7UOf0SIZqFNueqmpZx7lUKpRHNbZDL?usp=sharing
